--
-- PostgreSQL database dump
--

\restrict j0R9cijIjm1d0ky2B1bbOXcS4XW6aISudcKB67fb7dq66Nofq4WZHeAwFWicchb

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: appointments; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.appointments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid,
    type text NOT NULL,
    status text NOT NULL,
    reason text,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT appointments_status_check CHECK ((status = ANY (ARRAY['scheduled'::text, 'confirmed'::text, 'waiting'::text, 'in_progress'::text, 'done'::text, 'canceled'::text, 'no_show'::text]))),
    CONSTRAINT appointments_type_check CHECK ((type = ANY (ARRAY['in_person'::text, 'virtual'::text])))
);


ALTER TABLE public.appointments OWNER TO agx;

--
-- Name: attachments; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.attachments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    appointment_id uuid,
    file_name text NOT NULL,
    original_name text NOT NULL,
    mime text,
    size_bytes bigint,
    category text DEFAULT 'exam'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.attachments OWNER TO agx;

--
-- Name: audit_log; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.audit_log (
    id bigint NOT NULL,
    clinic_id uuid,
    user_id uuid,
    user_name text,
    method text,
    path text,
    ip text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.audit_log OWNER TO agx;

--
-- Name: audit_log_id_seq; Type: SEQUENCE; Schema: public; Owner: agx
--

CREATE SEQUENCE public.audit_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.audit_log_id_seq OWNER TO agx;

--
-- Name: audit_log_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: agx
--

ALTER SEQUENCE public.audit_log_id_seq OWNED BY public.audit_log.id;


--
-- Name: certificates; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.certificates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    provider_id uuid,
    diagnosis text,
    rest_days integer,
    observations text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.certificates OWNER TO agx;

--
-- Name: chat_messages; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.chat_messages (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    thread_id uuid NOT NULL,
    sender_id uuid,
    sender_name text,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_messages OWNER TO agx;

--
-- Name: chat_threads; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.chat_threads (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.chat_threads OWNER TO agx;

--
-- Name: clinics; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.clinics (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    address text,
    phone text
);


ALTER TABLE public.clinics OWNER TO agx;

--
-- Name: encounters; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.encounters (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    subjective text,
    objective text,
    assessment text,
    plan text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    cie10_code text,
    cie10_desc text
);


ALTER TABLE public.encounters OWNER TO agx;

--
-- Name: inventory_items; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.inventory_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    name text NOT NULL,
    category text DEFAULT 'med'::text NOT NULL,
    unit text,
    stock numeric(10,2) DEFAULT 0 NOT NULL,
    min_stock numeric(10,2) DEFAULT 0 NOT NULL,
    expiry_date date,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT inventory_items_category_check CHECK ((category = ANY (ARRAY['med'::text, 'supply'::text, 'other'::text]))),
    CONSTRAINT inventory_items_stock_check CHECK ((stock >= (0)::numeric))
);


ALTER TABLE public.inventory_items OWNER TO agx;

--
-- Name: patients; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.patients (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    first_name text NOT NULL,
    last_name text NOT NULL,
    id_number text,
    phone text,
    email text,
    birth_date date,
    sex text,
    allergies text,
    conditions text,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    family_history text,
    surgical_history text,
    habits text,
    medications text,
    CONSTRAINT patients_sex_check CHECK ((sex = ANY (ARRAY['male'::text, 'female'::text, 'other'::text])))
);


ALTER TABLE public.patients OWNER TO agx;

--
-- Name: payments; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.payments (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    appointment_id uuid,
    amount numeric(10,2) NOT NULL,
    method text DEFAULT 'cash'::text NOT NULL,
    status text DEFAULT 'paid'::text NOT NULL,
    concept text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT payments_amount_check CHECK ((amount >= (0)::numeric)),
    CONSTRAINT payments_method_check CHECK ((method = ANY (ARRAY['cash'::text, 'card'::text, 'transfer'::text, 'other'::text]))),
    CONSTRAINT payments_status_check CHECK ((status = ANY (ARRAY['paid'::text, 'pending'::text])))
);


ALTER TABLE public.payments OWNER TO agx;

--
-- Name: prescription_items; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.prescription_items (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    prescription_id uuid NOT NULL,
    medication text NOT NULL,
    dose text,
    frequency text,
    duration text,
    notes text
);


ALTER TABLE public.prescription_items OWNER TO agx;

--
-- Name: prescriptions; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.prescriptions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    provider_id uuid,
    patient_id uuid NOT NULL,
    instructions text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.prescriptions OWNER TO agx;

--
-- Name: reminders; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.reminders (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    title text NOT NULL,
    details text,
    schedule_cron text,
    next_run_at timestamp with time zone,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.reminders OWNER TO agx;

--
-- Name: templates; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.templates (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    type text NOT NULL,
    name text NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT templates_type_check CHECK ((type = ANY (ARRAY['rx'::text, 'dx'::text])))
);


ALTER TABLE public.templates OWNER TO agx;

--
-- Name: users; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.users (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    full_name text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT users_role_check CHECK ((role = ANY (ARRAY['superadmin'::text, 'admin'::text, 'staff'::text, 'provider'::text])))
);


ALTER TABLE public.users OWNER TO agx;

--
-- Name: vitals; Type: TABLE; Schema: public; Owner: agx
--

CREATE TABLE public.vitals (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    clinic_id uuid NOT NULL,
    patient_id uuid NOT NULL,
    taken_at timestamp with time zone DEFAULT now() NOT NULL,
    systolic integer,
    diastolic integer,
    heart_rate integer,
    spo2 integer,
    temperature_c numeric(4,1),
    weight_kg numeric(6,2),
    glucose_mgdl integer,
    notes text
);


ALTER TABLE public.vitals OWNER TO agx;

--
-- Name: audit_log id; Type: DEFAULT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.audit_log ALTER COLUMN id SET DEFAULT nextval('public.audit_log_id_seq'::regclass);


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.appointments (id, clinic_id, patient_id, provider_id, type, status, reason, starts_at, ends_at, created_at) FROM stdin;
a7e28b7c-2c62-4e8f-afbe-0996ae9d46ff	1c562250-8d60-40f3-8f59-754d72870cd0	f97b949c-67ff-4820-8b04-9767cd347c47	\N	in_person	in_progress	Consulta general (demo)	2026-07-29 02:40:23.985+00	2026-07-29 03:10:23.985+00	2026-07-29 02:10:23.986157+00
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.attachments (id, clinic_id, patient_id, appointment_id, file_name, original_name, mime, size_bytes, category, created_at) FROM stdin;
\.


--
-- Data for Name: audit_log; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.audit_log (id, clinic_id, user_id, user_name, method, path, ip, created_at) FROM stdin;
1	1c562250-8d60-40f3-8f59-754d72870cd0	c9af3174-67ce-4e9d-ba7d-f93746bcb4bb	Angel Alcivar	POST	/a7e28b7c-2c62-4e8f-afbe-0996ae9d46ff/status	::ffff:172.19.0.5	2026-07-29 02:16:10.26271+00
2	1c562250-8d60-40f3-8f59-754d72870cd0	c9af3174-67ce-4e9d-ba7d-f93746bcb4bb	Angel Alcivar	POST	/a7e28b7c-2c62-4e8f-afbe-0996ae9d46ff/status	::ffff:172.19.0.5	2026-07-29 02:16:11.476893+00
3	1c562250-8d60-40f3-8f59-754d72870cd0	c9af3174-67ce-4e9d-ba7d-f93746bcb4bb	Angel Alcivar	POST	/a7e28b7c-2c62-4e8f-afbe-0996ae9d46ff/status	::ffff:172.19.0.5	2026-07-29 02:16:12.937102+00
\.


--
-- Data for Name: certificates; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.certificates (id, clinic_id, appointment_id, patient_id, provider_id, diagnosis, rest_days, observations, created_at) FROM stdin;
\.


--
-- Data for Name: chat_messages; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.chat_messages (id, thread_id, sender_id, sender_name, body, created_at) FROM stdin;
\.


--
-- Data for Name: chat_threads; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.chat_threads (id, clinic_id, appointment_id, created_at) FROM stdin;
\.


--
-- Data for Name: clinics; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.clinics (id, name, created_at, address, phone) FROM stdin;
1c562250-8d60-40f3-8f59-754d72870cd0	Mi Consultorio	2026-07-29 02:10:23.840827+00	\N	\N
\.


--
-- Data for Name: encounters; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.encounters (id, clinic_id, appointment_id, subjective, objective, assessment, plan, created_at, cie10_code, cie10_desc) FROM stdin;
\.


--
-- Data for Name: inventory_items; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.inventory_items (id, clinic_id, name, category, unit, stock, min_stock, expiry_date, notes, created_at) FROM stdin;
\.


--
-- Data for Name: patients; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.patients (id, clinic_id, first_name, last_name, id_number, phone, email, birth_date, sex, allergies, conditions, notes, created_at, family_history, surgical_history, habits, medications) FROM stdin;
f97b949c-67ff-4820-8b04-9767cd347c47	1c562250-8d60-40f3-8f59-754d72870cd0	Juan	Pérez	\N	+593900000000	juan@example.com	\N	\N	Ninguna	Ninguna	\N	2026-07-29 02:10:23.982534+00	\N	\N	\N	\N
\.


--
-- Data for Name: payments; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.payments (id, clinic_id, patient_id, appointment_id, amount, method, status, concept, created_by, created_at) FROM stdin;
\.


--
-- Data for Name: prescription_items; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.prescription_items (id, prescription_id, medication, dose, frequency, duration, notes) FROM stdin;
\.


--
-- Data for Name: prescriptions; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.prescriptions (id, clinic_id, appointment_id, provider_id, patient_id, instructions, created_at) FROM stdin;
\.


--
-- Data for Name: reminders; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.reminders (id, clinic_id, patient_id, title, details, schedule_cron, next_run_at, is_active, created_at) FROM stdin;
\.


--
-- Data for Name: templates; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.templates (id, clinic_id, type, name, content, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.users (id, clinic_id, full_name, email, password_hash, role, created_at) FROM stdin;
f510a288-4040-4b27-8985-8cd4cde06e2f	1c562250-8d60-40f3-8f59-754d72870cd0	Admin AGX	admin@agx.local	$2a$10$MZIJtp5S7jHifKFOF5/CoekFk8q3NQUWA.WZQM2dIHzZrwX9V79oS	admin	2026-07-29 02:10:23.97291+00
c9af3174-67ce-4e9d-ba7d-f93746bcb4bb	1c562250-8d60-40f3-8f59-754d72870cd0	Angel Alcivar	angel@agx.local	$2a$10$wXXPuylwtUeTQ6gGT4WNa.A1EQ1N1E6PLf2KQ/wd9Yv/9BD6u5Ofq	superadmin	2026-07-29 02:10:23.978144+00
\.


--
-- Data for Name: vitals; Type: TABLE DATA; Schema: public; Owner: agx
--

COPY public.vitals (id, clinic_id, patient_id, taken_at, systolic, diastolic, heart_rate, spo2, temperature_c, weight_kg, glucose_mgdl, notes) FROM stdin;
\.


--
-- Name: audit_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: agx
--

SELECT pg_catalog.setval('public.audit_log_id_seq', 3, true);


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_log audit_log_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.audit_log
    ADD CONSTRAINT audit_log_pkey PRIMARY KEY (id);


--
-- Name: certificates certificates_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_pkey PRIMARY KEY (id);


--
-- Name: chat_messages chat_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_pkey PRIMARY KEY (id);


--
-- Name: chat_threads chat_threads_appointment_id_key; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_appointment_id_key UNIQUE (appointment_id);


--
-- Name: chat_threads chat_threads_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_pkey PRIMARY KEY (id);


--
-- Name: clinics clinics_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.clinics
    ADD CONSTRAINT clinics_pkey PRIMARY KEY (id);


--
-- Name: encounters encounters_appointment_id_key; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.encounters
    ADD CONSTRAINT encounters_appointment_id_key UNIQUE (appointment_id);


--
-- Name: encounters encounters_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.encounters
    ADD CONSTRAINT encounters_pkey PRIMARY KEY (id);


--
-- Name: inventory_items inventory_items_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_pkey PRIMARY KEY (id);


--
-- Name: patients patients_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_pkey PRIMARY KEY (id);


--
-- Name: payments payments_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_pkey PRIMARY KEY (id);


--
-- Name: prescription_items prescription_items_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_pkey PRIMARY KEY (id);


--
-- Name: prescriptions prescriptions_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_pkey PRIMARY KEY (id);


--
-- Name: reminders reminders_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_pkey PRIMARY KEY (id);


--
-- Name: templates templates_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_pkey PRIMARY KEY (id);


--
-- Name: users users_clinic_id_email_key; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clinic_id_email_key UNIQUE (clinic_id, email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: vitals vitals_pkey; Type: CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.vitals
    ADD CONSTRAINT vitals_pkey PRIMARY KEY (id);


--
-- Name: idx_appts_clinic_starts; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_appts_clinic_starts ON public.appointments USING btree (clinic_id, starts_at DESC);


--
-- Name: idx_appts_patient; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_appts_patient ON public.appointments USING btree (patient_id);


--
-- Name: idx_attach_patient; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_attach_patient ON public.attachments USING btree (patient_id);


--
-- Name: idx_audit_clinic; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_audit_clinic ON public.audit_log USING btree (clinic_id, created_at DESC);


--
-- Name: idx_chatmsg_thread; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_chatmsg_thread ON public.chat_messages USING btree (thread_id, created_at);


--
-- Name: idx_enc_appt; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_enc_appt ON public.encounters USING btree (appointment_id);


--
-- Name: idx_inventory_clinic; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_inventory_clinic ON public.inventory_items USING btree (clinic_id, name);


--
-- Name: idx_patients_clinic; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_patients_clinic ON public.patients USING btree (clinic_id, created_at DESC);


--
-- Name: idx_payments_clinic; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_payments_clinic ON public.payments USING btree (clinic_id, created_at DESC);


--
-- Name: idx_rx_clinic; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_rx_clinic ON public.prescriptions USING btree (clinic_id, created_at DESC);


--
-- Name: idx_vitals_patient_taken; Type: INDEX; Schema: public; Owner: agx
--

CREATE INDEX idx_vitals_patient_taken ON public.vitals USING btree (patient_id, taken_at DESC);


--
-- Name: appointments appointments_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: attachments attachments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: certificates certificates_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.certificates
    ADD CONSTRAINT certificates_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_sender_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_sender_id_fkey FOREIGN KEY (sender_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: chat_messages chat_messages_thread_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_messages
    ADD CONSTRAINT chat_messages_thread_id_fkey FOREIGN KEY (thread_id) REFERENCES public.chat_threads(id) ON DELETE CASCADE;


--
-- Name: chat_threads chat_threads_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- Name: chat_threads chat_threads_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.chat_threads
    ADD CONSTRAINT chat_threads_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: encounters encounters_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.encounters
    ADD CONSTRAINT encounters_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- Name: encounters encounters_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.encounters
    ADD CONSTRAINT encounters_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: inventory_items inventory_items_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.inventory_items
    ADD CONSTRAINT inventory_items_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: patients patients_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.patients
    ADD CONSTRAINT patients_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: payments payments_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE SET NULL;


--
-- Name: payments payments_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: payments payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: payments payments_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.payments
    ADD CONSTRAINT payments_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: prescription_items prescription_items_prescription_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescription_items
    ADD CONSTRAINT prescription_items_prescription_id_fkey FOREIGN KEY (prescription_id) REFERENCES public.prescriptions(id) ON DELETE CASCADE;


--
-- Name: prescriptions prescriptions_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- Name: prescriptions prescriptions_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: prescriptions prescriptions_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: prescriptions prescriptions_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.prescriptions
    ADD CONSTRAINT prescriptions_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: reminders reminders_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: reminders reminders_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.reminders
    ADD CONSTRAINT reminders_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- Name: templates templates_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.templates
    ADD CONSTRAINT templates_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: users users_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: vitals vitals_clinic_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.vitals
    ADD CONSTRAINT vitals_clinic_id_fkey FOREIGN KEY (clinic_id) REFERENCES public.clinics(id) ON DELETE CASCADE;


--
-- Name: vitals vitals_patient_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: agx
--

ALTER TABLE ONLY public.vitals
    ADD CONSTRAINT vitals_patient_id_fkey FOREIGN KEY (patient_id) REFERENCES public.patients(id) ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

\unrestrict j0R9cijIjm1d0ky2B1bbOXcS4XW6aISudcKB67fb7dq66Nofq4WZHeAwFWicchb

