--
-- PostgreSQL database dump
--

\restrict d8uCe9AHIDvfhHXvlgtEpO652Nts8OLddN0HF8gl3AouPHfiX58AFixLpAUs0sf

-- Dumped from database version 16.14 (Debian 16.14-1.pgdg13+1)
-- Dumped by pg_dump version 16.14 (Debian 16.14-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- PostgreSQL database dump complete
--

\unrestrict d8uCe9AHIDvfhHXvlgtEpO652Nts8OLddN0HF8gl3AouPHfiX58AFixLpAUs0sf

